NOVALEARN UPDATE

Files:
- index.html: updated website, based on your preview (3).html design
- server.js: Express backend with AI Tutor and AI quiz generation endpoints

IN YOUR CODESPACE:
1. Replace the existing preview (3).html content/file with this index.html (name it exactly index.html).
2. Replace the existing server.js with this server.js.
3. Keep package.json, package-lock.json, node_modules, and .gitignore.
4. Ensure .gitignore contains:
   .env
   node_modules/
5. In .env, set:
   OPENAI_API_KEY=your_real_api_key
   Optional: OPENAI_MODEL=gpt-5-mini
6. Restart the server:
   Ctrl+C
   node server.js
7. Open port 3000. The site should load at the forwarded port URL; /api/status reports backend status.

IMPORTANT:
- Never put the API key in index.html or commit .env.
- The signup in this starter build is a local browser profile, not real email/password authentication. Email verification and password reset require a configured authentication provider (such as Supabase or Firebase) and email delivery setup; this build does not pretend to send those emails.
- The AI features require an active OpenAI API key and API billing/usage access. A ChatGPT subscription is not an API key.
